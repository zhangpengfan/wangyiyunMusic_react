// import React, { useEffect, useContext } from "react";
// import MyContext from "../../component/Mycontext";
// import { songDetails, fetchSongList, musicSlider } from "../../service/index";
export default function Playlist() {
  // const Id = useContext(MyContext);
  // useEffect(() => {
  //   fetchSongList(Id)
  //     .then((res) => {
  //       console.log(res);
  //     })
  //     .catch((err) => {
  //       console.log(err);
  //     });
  // }, [Id]);
  // console.log("Id", Id);
  return <div>111</div>;
}
